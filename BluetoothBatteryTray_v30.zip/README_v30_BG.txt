BluetoothBatteryTray v30 — Battery Indicator Styles

В Settings → Appearance & displays → Battery indicator style:
- Percentage Only: досегашните цифри.
- Battery Icon + Percentage: малка зелена батерия + процент в главния tray, а на второстепенните монитори — Golden Rain батерия и цифри, без плочка отзад.

Избери режима и натисни Save settings. За основния Windows System Tray иконата е само 16x16, което ограничава четливостта на 100% при някои мащабирания.

Компилиране: BUILD_EXE.bat или dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -o publish_v30

Кодът не е компилиран/тестван на Windows в тази среда.
